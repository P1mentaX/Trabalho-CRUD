/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;
import java.util.Iterator;
import negocio.modelo.Funcionario;
import persistencia.dao.FuncionarioDAO;
import persistencia.interfaces.*;

/**
 *
 * @author dennis
 */
public class FuncionarioNegocio implements IFuncionarioCRUD{

    private IFuncionarioCRUD persistenciaFuncionario = null;
    
    public FuncionarioNegocio() throws Exception{
        try {
            persistenciaFuncionario = new FuncionarioDAO();
        } catch (Exception erro) {
            throw erro;
        }
    }
    
    @Override
    public void inserir(Funcionario funcionario) throws Exception {
        try {
            persistenciaFuncionario.inserir(funcionario);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void atualizar(Funcionario funcionario) throws Exception {
        try {
            persistenciaFuncionario.atualizar(funcionario);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void excluir(int numReg) throws Exception {
        try {
            persistenciaFuncionario.excluir(numReg);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Funcionario> listarTodos() throws Exception {
        try {
            return persistenciaFuncionario.listarTodos();
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Funcionario obterPorNumReg(int numReg) throws Exception {
        try {
            return persistenciaFuncionario.obterPorNumReg(numReg);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Funcionario obterPorNome(String nome) throws Exception {
        try {
            return persistenciaFuncionario.obterPorNome(nome);
        } catch (Exception erro) {
            throw erro;
        }
    }  
}
