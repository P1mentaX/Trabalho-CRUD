/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import negocio.modelo.Frete;
import persistencia.dao.FreteDAO;
import persistencia.interfaces.*;
/**
 *
 * @author dennis
 */
public class FreteNegocio implements IFreteCRUD{

    private IFreteCRUD persistenciaFrete = null;
    
    public FreteNegocio() throws Exception{
        try {
            persistenciaFrete = new FreteDAO();
        } catch (Exception erro) {
            throw erro;
        }
    }
    
    @Override
    public void inserir(Frete frete) throws Exception {
        try {
            persistenciaFrete.inserir(frete);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void atualizar(Frete frete) throws Exception {
        try {
            persistenciaFrete.atualizar(frete);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void excluir(int numConhecimento) throws Exception {
        try {
            persistenciaFrete.excluir(numConhecimento);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Frete> listarTodos() throws Exception {
        try {
            return persistenciaFrete.listarTodos();
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Frete obterPorNumeroConhecimento(int numConhecimento) throws Exception {
        try {
            return persistenciaFrete.obterPorNumeroConhecimento(numConhecimento);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Frete> listarPorCliente(int codCli) throws Exception {
        try {
            return persistenciaFrete.listarPorCliente(codCli);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Frete> listarPorFuncionario(int numReg) throws Exception {
        try {
            return persistenciaFrete.listarPorFuncionario(numReg);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Frete> listarPorData(Date dataInicio, Date dataFim) throws Exception {
        try {
            return persistenciaFrete.listarPorData(dataInicio, dataFim);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public List<Map<String, Object>> consultarArrecadacaoPorDestino(String uf, int ano) throws Exception {
        try {
            return persistenciaFrete.consultarArrecadacaoPorDestino(uf, ano);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public List<Map<String, Object>> consultarMediaFretesPorCidade(String uf) throws Exception {
        try {
            return persistenciaFrete.consultarMediaFretesPorCidade(uf);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public List<Map<String, Object>> consultarFretesPessoasJuridicas(int mes, int ano) throws Exception {
        try {
            return persistenciaFrete.consultarFretesPessoasJuridicas(mes, ano);
        } catch (Exception erro) {
            throw erro;
        }
    }
}
