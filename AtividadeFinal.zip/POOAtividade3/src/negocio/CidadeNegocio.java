/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;
import java.util.Iterator;
import negocio.modelo.Cidade;
import persistencia.dao.CidadeDAO;
import persistencia.interfaces.*;
/**
 *
 * @author dennis
 */
public class CidadeNegocio implements ICidadeCRUD{

    private ICidadeCRUD persistenciaCidade = null;
    
    public CidadeNegocio() throws Exception{
        try {
            persistenciaCidade = new CidadeDAO();
        } catch (Exception erro) {
            throw erro;
        }
    }
    
    @Override
    public void inserir(Cidade cidade) throws Exception {
        try {
            persistenciaCidade.inserir(cidade);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void atualizar(Cidade cidade) throws Exception {
        try {
            persistenciaCidade.atualizar(cidade);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void excluir(int codigoCid) throws Exception {
        try {
            persistenciaCidade.excluir(codigoCid);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Cidade> listarTodas() throws Exception {
        try {
            return persistenciaCidade.listarTodas();
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Cidade obterPorCodigo(int codigoCid) throws Exception {
        try {
            return persistenciaCidade.obterPorCodigo(codigoCid);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Cidade obterPorNome(String nome) throws Exception {
        try {
            return persistenciaCidade.obterPorNome(nome);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Cidade> listarPorEstado(String ufEstado) throws Exception {
        try {
            return persistenciaCidade.listarPorEstado(ufEstado);
        } catch (Exception erro) {
            throw erro;
        }
    }
    
}
