/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;
import java.util.Iterator;
import negocio.modelo.Representante;
import persistencia.dao.RepresentanteDAO;
import persistencia.interfaces.*;
/**
 *
 * @author dennis
 */
public class RepresentanteNegocio implements IRepresentanteCRUD{
    
    private IRepresentanteCRUD persistenciaRepresentante = null;
    
    public RepresentanteNegocio() throws Exception{
        try {
            persistenciaRepresentante = new RepresentanteDAO();
        } catch (Exception erro) {
            throw erro;
        }
    }
    
    @Override
    public void inserir(Representante representante) throws Exception {
        try {
            persistenciaRepresentante.inserir(representante);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void atualizar(Representante representante) throws Exception {
        try {
            persistenciaRepresentante.atualizar(representante);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void excluir(int idRepresentante) throws Exception {
        try {
            persistenciaRepresentante.excluir(idRepresentante);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Representante> listarTodos() throws Exception {
        try {
            return persistenciaRepresentante.listarTodos();
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Representante> listarPorRepresentado(int idClienteRepresentado) throws Exception {
        try {
            return persistenciaRepresentante.listarPorRepresentado(idClienteRepresentado);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Representante> listarPorRepresentante(int idClienteRepresentante) throws Exception {
        try {
            return persistenciaRepresentante.listarPorRepresentante(idClienteRepresentante);
        } catch (Exception erro) {
            throw erro;
        }
    }
    
    @Override
    public Representante obterRepresentante(int idRepresentante) throws Exception {
        try {
            return persistenciaRepresentante.obterRepresentante(idRepresentante);
        } catch (Exception erro) {
            throw erro;
        }
    }
    
}
