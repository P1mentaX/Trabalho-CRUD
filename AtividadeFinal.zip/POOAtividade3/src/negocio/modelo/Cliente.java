/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio.modelo;

import java.sql.Date;

public class Cliente {

    private int codCli;
    private Date dataInsc;
    private String endereco;
    private String telefone;
    private String razaoSocial; // Opcional para Pessoa Física
    private Integer inscEstadual; // Opcional para Pessoa Física
    private String cnpj; // Opcional para Pessoa Física
    private String nomeCli;
    private String cpf; // Opcional para Pessoa Jurídica
    private int clienteTipo; // 1 = Pessoa Física, 2 = Pessoa Jurídica

    public Cliente() {
    }

    public Cliente(Date dataInsc, String endereco, String telefone, String razaoSocial, Integer inscEstadual, String cnpj, String nomeCli, String cpf, int clienteTipo) {
        this.dataInsc = dataInsc;
        this.endereco = endereco;
        this.telefone = telefone;
        this.razaoSocial = razaoSocial;
        this.inscEstadual = inscEstadual;
        this.cnpj = cnpj;
        this.nomeCli = nomeCli;
        this.cpf = cpf;
        this.clienteTipo = clienteTipo;
    }

    public int getCodCli() {
        return codCli;
    }

    public void setCodCli(int codCli) {
        this.codCli = codCli;
    }

    public Date getDataInsc() {
        return dataInsc;
    }

    public void setDataInsc(Date dataInsc) {
        this.dataInsc = dataInsc;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public Integer getInscEstadual() {
        return inscEstadual;
    }

    public void setInscEstadual(Integer inscEstadual) {
        this.inscEstadual = inscEstadual;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNomeCli() {
        return nomeCli;
    }

    public void setNomeCli(String nomeCli) {
        this.nomeCli = nomeCli;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getClienteTipo() {
        return clienteTipo;
    }

    public void setClienteTipo(int clienteTipo) {
        this.clienteTipo = clienteTipo;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "codCli=" + codCli +
                ", dataInsc=" + dataInsc +
                ", endereco='" + endereco + '\'' +
                ", telefone='" + telefone + '\'' +
                ", razaoSocial='" + razaoSocial + '\'' +
                ", inscEstadual=" + inscEstadual +
                ", cnpj='" + cnpj + '\'' +
                ", nomeCli='" + nomeCli + '\'' +
                ", cpf='" + cpf + '\'' +
                ", clienteTipo=" + clienteTipo +
                '}';
    }
}

