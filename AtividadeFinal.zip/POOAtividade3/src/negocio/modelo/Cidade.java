/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio.modelo;

public class Cidade {

    private int codigoCid;
    private double precoUnitPeso;
    private double precoUnitValor;
    private String nomeCid;
    private String fkEstadoUf; // Chave estrangeira para Estado (referência ao atributo uf)

    public Cidade() {
    }

    public Cidade(double precoUnitPeso, double precoUnitValor, String nomeCid, String fkEstadoUf) {
        this.precoUnitPeso = precoUnitPeso;
        this.precoUnitValor = precoUnitValor;
        this.nomeCid = nomeCid;
        this.fkEstadoUf = fkEstadoUf;
    }

    public int getCodigoCid() {
        return codigoCid;
    }

    public void setCodigoCid(int codigoCid) {
        this.codigoCid = codigoCid;
    }

    public double getPrecoUnitPeso() {
        return precoUnitPeso;
    }

    public void setPrecoUnitPeso(double precoUnitPeso) {
        this.precoUnitPeso = precoUnitPeso;
    }

    public double getPrecoUnitValor() {
        return precoUnitValor;
    }

    public void setPrecoUnitValor(double precoUnitValor) {
        this.precoUnitValor = precoUnitValor;
    }

    public String getNomeCid() {
        return nomeCid;
    }

    public void setNomeCid(String nomeCid) {
        this.nomeCid = nomeCid;
    }

    public String getFkEstadoUf() {
        return fkEstadoUf;
    }

    public void setFkEstadoUf(String fkEstadoUf) {
        this.fkEstadoUf = fkEstadoUf;
    }

    @Override
    public String toString() {
        return "Cidade{" +
                "codigoCid=" + codigoCid +
                ", precoUnitPeso=" + precoUnitPeso +
                ", precoUnitValor=" + precoUnitValor +
                ", nomeCid='" + nomeCid + '\'' +
                ", fkEstadoUf='" + fkEstadoUf + '\'' +
                '}';
    }
}

