/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio.modelo;

import java.sql.Date;

public class Frete {

    private int numConhec;
    private String quemPaga;
    private double pesoValor;
    private double peso;
    private double valor;
    private double icms;
    private Date dataFrete;
    private double pedagio;
    private int fkCidadeOrigem;
    private int fkCidadeDestino;
    private int fkFuncionarioNumReg;
    private int fkClienteRemetente;
    private int fkClienteDestinatario;

    public Frete() {
    }

    public Frete(String quemPaga, double pesoValor, double peso, double valor, double icms, Date dataFrete, double pedagio, int fkCidadeOrigem, int fkCidadeDestino, int fkFuncionarioNumReg, int fkClienteRemetente, int fkClienteDestinatario) {
        this.quemPaga = quemPaga;
        this.pesoValor = pesoValor;
        this.peso = peso;
        this.valor = valor;
        this.icms = icms;
        this.dataFrete = dataFrete;
        this.pedagio = pedagio;
        this.fkCidadeOrigem = fkCidadeOrigem;
        this.fkCidadeDestino = fkCidadeDestino;
        this.fkFuncionarioNumReg = fkFuncionarioNumReg;
        this.fkClienteRemetente = fkClienteRemetente;
        this.fkClienteDestinatario = fkClienteDestinatario;
    }

    public int getNumConhec() {
        return numConhec;
    }

    public void setNumConhec(int numConhec) {
        this.numConhec = numConhec;
    }

    public String getQuemPaga() {
        return quemPaga;
    }

    public void setQuemPaga(String quemPaga) {
        this.quemPaga = quemPaga;
    }

    public double getPesoValor() {
        return pesoValor;
    }

    public void setPesoValor(double pesoValor) {
        this.pesoValor = pesoValor;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public double getIcms() {
        return icms;
    }

    public void setIcms(double icms) {
        this.icms = icms;
    }

    public Date getDataFrete() {
        return dataFrete;
    }

    public void setDataFrete(Date dataFrete) {
        this.dataFrete = dataFrete;
    }

    public double getPedagio() {
        return pedagio;
    }

    public void setPedagio(double pedagio) {
        this.pedagio = pedagio;
    }

    public int getFkCidadeOrigem() {
        return fkCidadeOrigem;
    }

    public void setFkCidadeOrigem(int fkCidadeOrigem) {
        this.fkCidadeOrigem = fkCidadeOrigem;
    }

    public int getFkCidadeDestino() {
        return fkCidadeDestino;
    }

    public void setFkCidadeDestino(int fkCidadeDestino) {
        this.fkCidadeDestino = fkCidadeDestino;
    }

    public int getFkFuncionarioNumReg() {
        return fkFuncionarioNumReg;
    }

    public void setFkFuncionarioNumReg(int fkFuncionarioNumReg) {
        this.fkFuncionarioNumReg = fkFuncionarioNumReg;
    }

    public int getFkClienteRemetente() {
        return fkClienteRemetente;
    }

    public void setFkClienteRemetente(int fkClienteRemetente) {
        this.fkClienteRemetente = fkClienteRemetente;
    }

    public int getFkClienteDestinatario() {
        return fkClienteDestinatario;
    }

    public void setFkClienteDestinatario(int fkClienteDestinatario) {
        this.fkClienteDestinatario = fkClienteDestinatario;
    }

    @Override
    public String toString() {
        return "Frete{" +
                "numConhec=" + numConhec +
                ", quemPaga='" + quemPaga + '\'' +
                ", pesoValor=" + pesoValor +
                ", peso=" + peso +
                ", valor=" + valor +
                ", icms=" + icms +
                ", dataFrete=" + dataFrete +
                ", pedagio=" + pedagio +
                ", fkCidadeOrigem=" + fkCidadeOrigem +
                ", fkCidadeDestino=" + fkCidadeDestino +
                ", fkFuncionarioNumReg=" + fkFuncionarioNumReg +
                ", fkClienteRemetente=" + fkClienteRemetente +
                ", fkClienteDestinatario=" + fkClienteDestinatario +
                '}';
    }
}

