/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio.modelo;

public class Representante {
    private int id;
    private Integer fkClienteRepresentado;
    private Integer fkClienteRepresentante;

    public Representante() {
    }

    public Representante(Integer fkClienteRepresentado, Integer fkClienteRepresentante) {
        this.fkClienteRepresentado = fkClienteRepresentado;
        this.fkClienteRepresentante = fkClienteRepresentante;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public Integer getFkClienteRepresentado() {
        return fkClienteRepresentado;
    }

    public void setFkClienteRepresentado(Integer fkClienteRepresentado) {
        this.fkClienteRepresentado = fkClienteRepresentado;
    }

    public Integer getFkClienteRepresentante() {
        return fkClienteRepresentante;
    }

    public void setFkClienteRepresentante(Integer fkClienteRepresentante) {
        this.fkClienteRepresentante = fkClienteRepresentante;
    }

    @Override
    public String toString() {
        return "Representante{" +
                "fkClienteRepresentado=" + fkClienteRepresentado +
                ", fkClienteRepresentante=" + fkClienteRepresentante +
                '}';
    }
}

