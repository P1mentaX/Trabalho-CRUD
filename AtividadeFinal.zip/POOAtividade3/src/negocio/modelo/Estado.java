/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio.modelo;

public class Estado {

    private String uf;
    private double icmsLocal;
    private double icmsOutroUf;
    private String nomeEst;

    public Estado() {
    }

    public Estado(String uf, double icmsLocal, double icmsOutroUf, String nomeEst) {
        this.uf = uf;
        this.icmsLocal = icmsLocal;
        this.icmsOutroUf = icmsOutroUf;
        this.nomeEst = nomeEst;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public double getIcmsLocal() {
        return icmsLocal;
    }

    public void setIcmsLocal(double icmsLocal) {
        this.icmsLocal = icmsLocal;
    }

    public double getIcmsOutroUf() {
        return icmsOutroUf;
    }

    public void setIcmsOutroUf(double icmsOutroUf) {
        this.icmsOutroUf = icmsOutroUf;
    }

    public String getNomeEst() {
        return nomeEst;
    }

    public void setNomeEst(String nomeEst) {
        this.nomeEst = nomeEst;
    }

    @Override
    public String toString() {
        return "Estado{" +
                "uf='" + uf + '\'' +
                ", icmsLocal=" + icmsLocal +
                ", icmsOutroUf=" + icmsOutroUf +
                ", nomeEst='" + nomeEst + '\'' +
                '}';
    }
}

