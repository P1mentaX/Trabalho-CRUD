/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio.modelo;

public class Funcionario {

    private int numReg;
    private String nomeFunc;

    public Funcionario() {
    }

    public Funcionario(String nomeFunc) {
        this.nomeFunc = nomeFunc;
    }

    public int getNumReg() {
        return numReg;
    }

    public void setNumReg(int numReg) {
        this.numReg = numReg;
    }

    public String getNomeFunc() {
        return nomeFunc;
    }

    public void setNomeFunc(String nomeFunc) {
        this.nomeFunc = nomeFunc;
    }

    @Override
    public String toString() {
        return "Funcionario{" +
                "numReg=" + numReg +
                ", nomeFunc='" + nomeFunc + '\'' +
                '}';
    }
}

