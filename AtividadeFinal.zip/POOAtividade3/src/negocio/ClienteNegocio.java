/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;
import java.util.Iterator;
import negocio.modelo.Cliente;
import persistencia.dao.ClienteDAO;
import persistencia.interfaces.*;
/**
 *
 * @author dennis
 */
public class ClienteNegocio implements IClienteCRUD{

    private IClienteCRUD persistenciaCliente = null;

    public ClienteNegocio() throws Exception{
        try {
            persistenciaCliente = new ClienteDAO();
        } catch (Exception erro) {
            throw erro;
        }
    }
    
    @Override
    public void inserir(Cliente cliente) throws Exception {
        try {
            persistenciaCliente.inserir(cliente);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void atualizar(Cliente cliente) throws Exception {
        try {
            persistenciaCliente.atualizar(cliente);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void excluir(int codCli) throws Exception {
        try {
            persistenciaCliente.excluir(codCli);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Cliente> listarTodos() throws Exception {
        try {
            return persistenciaCliente.listarTodos();
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Cliente obterPorCodigo(int codCli) throws Exception {
        try {
            return persistenciaCliente.obterPorCodigo(codCli);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Cliente obterPorCNPJ(String cnpj) throws Exception {
        try {
            return persistenciaCliente.obterPorCNPJ(cnpj);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Cliente obterPorCPF(String cpf) throws Exception {
        try {
            return persistenciaCliente.obterPorCPF(cpf);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Cliente obterPorNome(String nome) throws Exception {
        try {
            return persistenciaCliente.obterPorNome(nome);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Cliente> listarPorTipo(int tipo) throws Exception {
        try {
            return persistenciaCliente.listarPorTipo(tipo);
        } catch (Exception erro) {
            throw erro;
        }
    }
}
