/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;
import java.util.Iterator;
import negocio.modelo.Estado;
import persistencia.dao.EstadoDAO;
import persistencia.interfaces.*;
/**
 *
 * @author dennis
 */
public class EstadoNegocio implements IEstadoCRUD{
    
    private IEstadoCRUD persistenciaEstado = null;

    public EstadoNegocio() throws Exception{
        try {
            persistenciaEstado = new EstadoDAO();
        } catch (Exception erro) {
            throw erro;
        }
    }
        
    @Override
    public void inserir(Estado estado) throws Exception {
        try {
            persistenciaEstado.inserir(estado);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void atualizar(Estado estado) throws Exception {
        try {
            persistenciaEstado.atualizar(estado);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public void excluir(String uf) throws Exception {
        try {
            persistenciaEstado.excluir(uf);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Iterator<Estado> listarTodos() throws Exception {
        try {
            return persistenciaEstado.listarTodos();
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Estado obterPorUF(String uf) throws Exception {
        try {
            return persistenciaEstado.obterPorUF(uf);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public Estado obterPorNome(String nome) throws Exception {
        try {
            return persistenciaEstado.obterPorNome(nome);
        } catch (Exception erro) {
            throw erro;
        }
    }

    @Override
    public String getNomeByUF(String uf) throws Exception {
        try {
            return persistenciaEstado.getNomeByUF(uf);
        } catch (Exception erro) {
            throw erro;
        }
    }
}
