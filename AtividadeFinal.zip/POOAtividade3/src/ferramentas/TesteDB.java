/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ferramentas;

import persistencia.dao.*;
import negocio.modelo.*;
import java.util.Calendar;
import java.sql.*;
import java.util.Iterator;

public class TesteDB {

    public static void main(String[] args) throws Exception {
        // -----------------TESTE PARA TABELA ESTADOS ----------------------------//

        //CREATE (INCLUSAO DE NOVOS ESTADOS)
        /*
        EstadoDAO estadoDAO = new EstadoDAO();
        Estado estado = new Estado("DF", 4, 12, "Distrito Federal");
        estadoDAO.inserir(estado);
        Iterator<Estado>listaEstado = estadoDAO.listarTodos();
        while(listaEstado.hasNext()){
            Estado estadol = listaEstado.next();
            System.out.println(estadol.getUf());
            System.out.println(estadol.getNomeEst());
            System.out.println(estadol);
            System.out.println("\n");
        }
         */
        // READ (LEITURA DE ESTADOS)
        /*
        // LISTAGEM DE TODOS
        EstadoDAO estadoDAO = new EstadoDAO();
        Iterator<Estado>listaEstado = estadoDAO.listarTodos();
        while(listaEstado.hasNext()){
            Estado estadol = listaEstado.next();
            System.out.println(estadol.getUf());
            System.out.println(estadol.getNomeEst());
            System.out.println(estadol);
            System.out.println("\n");
        }
        // LISTAGEM POR UF
        Estado estadoBusca = new Estado();
        estadoBusca = estadoDAO.obterPorUF("GO");
        System.out.println(estadoBusca);
        System.out.println("\n");
        
        // LISTAGEM POR NOME
        estadoBusca = estadoDAO.obterPorUF("Sao Paulo");
        System.out.println(estadoBusca);
        System.out.println("\n");
         */
        //UPDATE (ATUALIZACAO DE ESTADOS)
        /*
        EstadoDAO estadoDAO = new EstadoDAO();
        Estado estadoExistente = estadoDAO.obterPorUF("GO");
        System.out.println(estadoExistente);
        estadoExistente.setIcmsLocal(6);
        estadoExistente.setIcmsOutroUf(6);
        estadoExistente.setNomeEst("Goias");
                     
        estadoDAO.atualizar(estadoExistente);
        System.out.println(estadoExistente);
         */
        //DELETE (EXCLUSAO DE ESTADOS)
        /*
        EstadoDAO estadoDAO = new EstadoDAO();
        estadoDAO.excluir("RJ");
         */
        // -----------------TESTE PARA TABELA CIDADE ----------------------------//
        //CREATE (INCLUSAO DE NOVAS CIDADES)
        /*
        CidadeDAO cidadeDAO = new CidadeDAO();
        Cidade cidade = new Cidade(5, 5, "Macae", "RJ");
        cidadeDAO.inserir(cidade);
        Iterator<Cidade>listaCidades = cidadeDAO.listarTodas();
        while(listaCidades.hasNext()){
            Cidade cidadel = listaCidades.next();
            System.out.println(cidadel.getNomeCid());
            System.out.println(cidadel.getPrecoUnitPeso());
            System.out.println(cidadel.getPrecoUnitValor());
            System.out.println(cidadel);
            System.out.println("\n");
        }*/
        //READ (LEITURA DE CIDADES)
        //LISTAGEM DE TODAS CIDADES
        /*
        CidadeDAO cidadeDAO = new CidadeDAO();
        Iterator<Cidade>listaCidades = cidadeDAO.listarTodas();
        while(listaCidades.hasNext()){
            Cidade cidadel = listaCidades.next();
            System.out.println(cidadel.getNomeCid());
            System.out.println(cidadel.getPrecoUnitPeso());
            System.out.println(cidadel.getPrecoUnitValor());
            System.out.println(cidadel);
            System.out.println("\n");
        }*/
        //OBTER CIDADE POR CODIGO
        /*
        Cidade cidadeBusca = new Cidade();
        cidadeBusca = cidadeDAO.obterPorCodigo(6);
        System.out.println(cidadeBusca);
        System.out.println("\n");
         */
        //LISTAGEM POR NOME DA CIDADE
        /*
        Cidade cidadeBusca = new Cidade();
        cidadeBusca = cidadeDAO.obterPorNome("Goiania");
        System.out.println(cidadeBusca);
        System.out.println("\n");
         */
        //LISTAGEM POR ESTADO
        /*
        Iterator<Cidade>listaCidades = cidadeDAO.listarPorEstado("AC");
        while(listaCidades.hasNext()){
            Cidade cidadel = listaCidades.next();
            System.out.println(cidadel.getNomeCid());
            System.out.println(cidadel.getPrecoUnitPeso());
            System.out.println(cidadel.getPrecoUnitValor());
            System.out.println(cidadel);
            System.out.println("\n");
        }
         */
        //UPDATE (ATUALIZACAO DE CIDADES)
        /*
        CidadeDAO cidadeDAO = new CidadeDAO();
        Cidade cidadeExistente = cidadeDAO.obterPorNome("Rio Branco");
        System.out.println(cidadeExistente);
        cidadeExistente.setPrecoUnitPeso(6);          
        cidadeDAO.atualizar(cidadeExistente);
        System.out.println(cidadeExistente);
         */
        //DELETE (EXCLUSAO DE ESTADOS)
        /*
        CidadeDAO cidadeDAO = new CidadeDAO();
        cidadeDAO.excluir(3);
         */
        // -----------------TESTE PARA TABELA FUNCIONARIO ----------------------------//
        //CREATE (INCLUSAO DE NOVOS FUNCIONARIOS)
        /*
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
        Funcionario funcionario = new Funcionario();
        funcionario.setNomeFunc("Limas Pereira");
        funcionarioDAO.inserir(funcionario);
        Iterator<Funcionario> listaFuncionarios = funcionarioDAO.listarTodos();
        while (listaFuncionarios.hasNext()) {
            Funcionario func = listaFuncionarios.next();
            System.out.println(func.getNumReg());
            System.out.println(func.getNomeFunc());
            System.out.println(func);
            System.out.println("\n");
        }
         */
        // READ (LEITURA DE FUNCIONARIOS)
        // LISTAGEM DE TODOS FUNCIONARIOS
        /*
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
        Iterator<Funcionario> listaFuncionarios = funcionarioDAO.listarTodos();
        while (listaFuncionarios.hasNext()) {
            Funcionario func = listaFuncionarios.next();
            System.out.println(func.getNumReg());
            System.out.println(func.getNomeFunc());
            System.out.println(func);
            System.out.println("\n");
        }
         */
        // OBTER FUNCIONARIO POR NUM_REG
        /*
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
        Funcionario funcionarioBusca = new Funcionario();
        funcionarioBusca= funcionarioDAO.obterPorNumReg(3);
        System.out.println(funcionarioBusca);
        System.out.println("\n");
         */
        // OBTER FUNCIONARIO POR NOME
        /*
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
        Funcionario funcionarioBusca = new Funcionario();
        funcionarioBusca = funcionarioDAO.obterPorNome("Sonia Vargas");
        System.out.println(funcionarioBusca);
        System.out.println("\n");
         */
        //UPDATE (ATUALIZACAO DE FUNCIONARIOS)
        /*
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
        Funcionario funcionarioExistente = funcionarioDAO.obterPorNumReg(1);
        System.out.println(funcionarioExistente);
        funcionarioExistente.setNomeFunc("Carlos Eduardo Silva");
        funcionarioDAO.atualizar(funcionarioExistente);
        System.out.println(funcionarioExistente);
         */
        //DELETE (EXCLUSAO DE FUNCIONARIOS)
        /*
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
        funcionarioDAO.excluir(5);
         */
        
        // ----------------- TESTE PARA TABELA CLIENTE ----------------------------//
        // CREATE (INSERÇÃO DE NOVO CLIENTE)
        /*
        ClienteDAO clienteDAO = new ClienteDAO();
        Calendar calendar = Calendar.getInstance();
        Date dataInscricao = new Date(calendar.getTime().getTime());
        Cliente cliente = new Cliente(
            dataInscricao,                       // Data de inscrição
            "Avenida Quarta Meira, Edificion Palco 4, Apartamento 1",                  // Endereço
            "76958-3954",                        // Telefone
            "Kimo Team LLC",              // Razão Social (para Pessoa Jurídica)
            121254879,                           // Inscrição Estadual (para PJ)
            "42.335.118/0021-01",                // CNPJ (para PJ)
            "Riberth Kimo",              // Nome do Cliente
            "256.269.333-12",                    // CPF (para Pessoa Física)
            2                                    // Tipo de Cliente (1 = PF, 2 = PJ)
        );
        clienteDAO.inserir(cliente);
        
        // Listando todos os clientes após inserção
        Iterator<Cliente> listaClientes = clienteDAO.listarTodos();
        while (listaClientes.hasNext()) {
            Cliente clienteLista = listaClientes.next();
            System.out.println(clienteLista.getCodCli());
            System.out.println(clienteLista.getNomeCli());
            System.out.println(clienteLista);
            System.out.println("\n");
        }
         */
        // READ (LEITURA DE CLIENTES)
        // LISTAGEM DE TODOS CLIENTES
        /*
        ClienteDAO clienteDAO = new ClienteDAO();
        Iterator<Cliente> listaClientes = clienteDAO.listarTodos();
        while (listaClientes.hasNext()) {
            Cliente clienteLista = listaClientes.next();
            System.out.println(clienteLista.getCodCli());
            System.out.println(clienteLista.getNomeCli());
            System.out.println(clienteLista);
            System.out.println("\n");
        }
         */
        // OBTER CLIENTE POR CÓDIGO
        /*
        ClienteDAO clienteDAO = new ClienteDAO();
        Cliente clienteBusca = clienteDAO.obterPorCodigo(5);
        System.out.println(clienteBusca);
        System.out.println("\n");
         */
        // OBTER CLIENTE POR NOME
        /*
        ClienteDAO clienteDAO = new ClienteDAO();
        Cliente clienteBusca = clienteDAO.obterPorNome("Melinda Warner");
        System.out.println(clienteBusca);
        System.out.println("\n");
         */
        // UPDATE (ATUALIZAÇÃO DE CLIENTE)
        /*
        ClienteDAO clienteDAO = new ClienteDAO();
        Cliente clienteExistente = clienteDAO.obterPorCodigo(5);
        System.out.println(clienteExistente);
        
        // Alterando informações do cliente
        //clienteExistente.setNomeCli("Nome Cliente Atualizado");
        clienteExistente.setEndereco("Avenida Quarta Meira, Edificio Palco 4, Apartamento 1");
        clienteExistente.setClienteTipo(2);
        //clienteDAO.atualizar(clienteExistente);
        //System.out.println("Cliente atualizado:");
        System.out.println(clienteExistente);
         */
        // DELETE (EXCLUSÃO DE CLIENTE)
        /*
        ClienteDAO clienteDAO = new ClienteDAO();
        clienteDAO.excluir(5);
        System.out.println("Cliente excluído com sucesso.");
         */
        // -----------------TESTE PARA TABELA FRETE ----------------------------//
        // CREATE (INSERÇÃO DE NOVO FRETE)
        /*
        Calendar calendar = Calendar.getInstance();
        calendar.set(2024, 11, 20);
        Date dataFrete = new Date(calendar.getTime().getTime());
        FreteDAO freteDAO = new FreteDAO();
        Frete frete = new Frete(
                "Remetente", // quem paga
                100.20, // pesoValor
                10.0, // peso
                1020.0, // valor
                12.0, // icms
                dataFrete, // dataFrete
                0.0, // pedagio
                1, // cidade de origem
                5, // cidade de destino
                1, // funcionario
                4, //cliente remetente
                2 // cliente destinatario
        );
             
        freteDAO.inserir(frete);
        
        Iterator<Frete> listaFretes = freteDAO.listarTodos();
        while (listaFretes.hasNext()) {
            Frete freteLista = listaFretes.next();
            System.out.println(freteLista.getNumConhec());
            System.out.println(freteLista.getQuemPaga());
            System.out.println(freteLista);
            System.out.println("\n");
        }
        */
        
        // READ (LEITURA DE FRETES)
        // LISTAGEM DE TODOS OS FRETES
        /*
        FreteDAO freteDAO = new FreteDAO();
        Iterator<Frete> listaFretes = freteDAO.listarTodos();
        while (listaFretes.hasNext()) {
            Frete freteLista = listaFretes.next();
            System.out.println(freteLista.getNumConhec());
            System.out.println(freteLista.getQuemPaga());
            System.out.println(freteLista);
            System.out.println("\n");
        }
        */
        // OBTER FRETE POR NÚMERO DO CONHECIMENTO
        /*
        FreteDAO freteDAO = new FreteDAO();
        Frete freteBusca = freteDAO.obterPorNumeroConhecimento(1);
        System.out.println(freteBusca);
        System.out.println("\n");
        */
        // UPDATE (ATUALIZAÇÃO DE FRETE)
        /*
        FreteDAO freteDAO = new FreteDAO();
        Frete freteExistente = freteDAO.obterPorNumeroConhecimento(1);
        System.out.println(freteExistente);
        freteExistente.setValor(550.0);
        freteExistente.setIcms(20.0);
        freteDAO.atualizar(freteExistente);
        System.out.println("Frete atualizado:");
        System.out.println(freteExistente);
        */
        
        //DELETE (EXCLUSÃO DE FRETE)
        /*
        FreteDAO freteDAO = new FreteDAO();
        freteDAO.excluir(1);
        System.out.println("Frete excluído com sucesso.");
        */
        
        // -----------------TESTE PARA TABELA REPRESENTANTE ----------------------------//
        // CREATE (INSERÇÃO DE NOVO REPRESENTANTE)
        /*
        RepresentanteDAO representanteDAO = new RepresentanteDAO();
        Representante representante = new Representante(1, 2);
        representanteDAO.inserir(representante);

        Iterator<Representante> listaRepresentantes = representanteDAO.listarTodos();
        while (listaRepresentantes.hasNext()) {
            Representante representanteLista = listaRepresentantes.next();
            System.out.println("Representado: " + representanteLista.getFkClienteRepresentado());
            System.out.println("Representante: " + representanteLista.getFkClienteRepresentante());
            System.out.println(representanteLista);
            System.out.println("\n");
        }
        */
        // READ (LEITURA DE REPRESENTANTES)
        // LISTAGEM DE TODOS OS REPRESENTANTES
        /*
        RepresentanteDAO representanteDAO = new RepresentanteDAO();
        ClienteDAO clienteBusca = new ClienteDAO();
        Iterator<Representante> listaRepresentantes = representanteDAO.listarTodos();
        while (listaRepresentantes.hasNext()) {
            Representante representanteLista = listaRepresentantes.next();
            System.out.println("Representado: " +  clienteBusca.obterPorCodigo(representanteLista.getFkClienteRepresentado()).getNomeCli());
            System.out.println("Representante: " + clienteBusca.obterPorCodigo(representanteLista.getFkClienteRepresentante()).getNomeCli());
            System.out.println(representanteLista);
            System.out.println("\n");
        }
        */
        // LISTAGEM POR CLIENTE REPRESENTADO
        /*
        RepresentanteDAO representanteDAO = new RepresentanteDAO();
        ClienteDAO clienteBusca = new ClienteDAO();
        Iterator<Representante> listaPorRepresentado = representanteDAO.listarPorRepresentado(1); // Substituir com ID do cliente representado
        while (listaPorRepresentado.hasNext()) {
            Representante representante = listaPorRepresentado.next();
            System.out.println("Representado: " +  clienteBusca.obterPorCodigo(representante.getFkClienteRepresentado()).getNomeCli());
            System.out.println("Representante: " + clienteBusca.obterPorCodigo(representante.getFkClienteRepresentante()).getNomeCli());
            System.out.println(representante);
            System.out.println("\n");
        }
        */
        // LISTAGEM POR CLIENTE REPRESENTANTE
        /*
        RepresentanteDAO representanteDAO = new RepresentanteDAO();
        Iterator<Representante> listaPorRepresentante = representanteDAO.listarPorRepresentante(2); // Substituir com ID do cliente representante
        while (listaPorRepresentante.hasNext()) {
            Representante representante = listaPorRepresentante.next();
            System.out.println("Representado: " + representante.getFkClienteRepresentado());
            System.out.println("Representante: " + representante.getFkClienteRepresentante());
            System.out.println(representante);
            System.out.println("\n");
        }
        */
        // UPDATE (ATUALIZAÇÃO DE REPRESENTANTE)
        // ERRADO PRECISA ADICIONAR OBTER POR ID para modificar
        /*
        RepresentanteDAO representanteDAO = new RepresentanteDAO();
        Representante representanteExistente = new Representante(1, 2); // Substituir com IDs válidos
        representanteExistente.setFkClienteRepresentante(2); // Novo ID do cliente representante
        representanteDAO.atualizar(representanteExistente);
        System.out.println("Representante atualizado:");
        System.out.println(representanteExistente);
        */
        // DELETE (EXCLUSÃO DE REPRESENTANTE)
        /*
        RepresentanteDAO representanteDAO = new RepresentanteDAO();
        representanteDAO.excluir(1, 2); // Substituir com IDs de cliente representado e representante
        System.out.println("Representante excluído com sucesso.");
        */
    }
}
