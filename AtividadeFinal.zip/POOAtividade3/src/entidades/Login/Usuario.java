/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.Login;

/**
 *
 * @author naels
 */
public class Usuario implements ILogin{
    private String email;
    private String senha;
    private int emailHash;
    private int senhaHash;
    public Usuario(){
        
    }
    
    public Usuario(String email, String senha) {
        this.email = email;
        this.senha = senha;
        this.emailHash = this.hashString(email);
        this.senhaHash = this.hashString(senha);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    public int getEmailHash() {
        return emailHash;
    }

    public void setEmailHash(int emailHash) {
        this.emailHash = emailHash;
    }

    public int getSenhaHash() {
        return senhaHash;
    }

    public void setSenhaHash(int senhaHash) {
        this.senhaHash = senhaHash;
    }

    @Override
    public int hashString(String string) {
        int hashValue = 0;
        // faz varredura em cada caracter da string
        for (char c : string.toCharArray()) {
            // pega o valor ASCII de cada caractere da string
            int asciiValue = (int) c;
            // Adiciona ao valor hash
            hashValue += asciiValue;
        }
        // multiplica o valor da hash obtido por um numero primo grande
        hashValue *= 15485863;
        return hashValue;
    }

    @Override
    public boolean verificarSenha() throws Exception{
        if (this.emailHash != 2100694123 || this.senhaHash != -428884791) throw new Exception("Usuario ou senha invalida!");
        return true;
    }
    
}
