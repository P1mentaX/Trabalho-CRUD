/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistencia.interfaces;

import negocio.modelo.Estado;
import java.util.Iterator;

public interface IEstadoCRUD {
    public void inserir(Estado estado) throws Exception;
    public void atualizar(Estado estado) throws Exception;
    public void excluir(String uf) throws Exception;
    public Iterator<Estado> listarTodos() throws Exception;
    public Estado obterPorUF(String uf) throws Exception;
    public Estado obterPorNome(String nome) throws Exception;
    public String getNomeByUF(String uf) throws Exception;
}