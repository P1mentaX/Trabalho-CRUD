/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistencia.interfaces;

import negocio.modelo.Representante;
import java.util.Iterator;

public interface IRepresentanteCRUD {
    public void inserir(Representante representante) throws Exception;
    public void atualizar(Representante representante) throws Exception;
    public void excluir(int idRepresentante) throws Exception;
    public Iterator<Representante> listarTodos() throws Exception;
    public Iterator<Representante> listarPorRepresentado(int idClienteRepresentado) throws Exception;
    public Iterator<Representante> listarPorRepresentante(int idClienteRepresentante) throws Exception;
    public Representante obterRepresentante(int idRepresentante) throws Exception;
}
