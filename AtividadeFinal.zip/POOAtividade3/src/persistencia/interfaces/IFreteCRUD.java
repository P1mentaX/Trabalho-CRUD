/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistencia.interfaces;

import negocio.modelo.Frete;
import java.util.Iterator;
import java.util.Date;
import java.util.List;
import java.util.Map;

public interface IFreteCRUD {
    public void inserir(Frete frete) throws Exception;
    public void atualizar(Frete frete) throws Exception;
    public void excluir(int numConhecimento) throws Exception;
    public Iterator<Frete> listarTodos() throws Exception;
    public Frete obterPorNumeroConhecimento(int numConhecimento) throws Exception;
    public Iterator<Frete> listarPorCliente(int codCli) throws Exception;
    public Iterator<Frete> listarPorFuncionario(int numReg) throws Exception;
    public Iterator<Frete> listarPorData(Date dataInicio, Date dataFim) throws Exception;
    public List<Map<String, Object>> consultarArrecadacaoPorDestino(String uf, int ano) throws Exception;
    public List<Map<String, Object>> consultarMediaFretesPorCidade(String uf) throws Exception;
    public List<Map<String, Object>> consultarFretesPessoasJuridicas(int mes, int ano) throws Exception;
}