/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistencia.interfaces;

import negocio.modelo.Funcionario;
import java.util.Iterator;

public interface IFuncionarioCRUD {
    public void inserir(Funcionario funcionario) throws Exception;
    public void atualizar(Funcionario funcionario) throws Exception;
    public void excluir(int numReg) throws Exception;
    public Iterator<Funcionario> listarTodos() throws Exception;
    public Funcionario obterPorNumReg(int numReg) throws Exception;
    public Funcionario obterPorNome(String nome) throws Exception;
}