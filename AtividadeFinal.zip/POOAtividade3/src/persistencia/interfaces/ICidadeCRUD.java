/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistencia.interfaces;

import negocio.modelo.Cidade;
import java.util.Iterator;

public interface ICidadeCRUD {
    public void inserir(Cidade cidade) throws Exception;
    public void atualizar(Cidade cidade) throws Exception;
    public void excluir(int codigoCid) throws Exception;
    public Iterator<Cidade> listarTodas() throws Exception;
    public Cidade obterPorCodigo(int codigoCid) throws Exception;
    public Cidade obterPorNome(String nome) throws Exception;
    public Iterator<Cidade> listarPorEstado(String ufEstado) throws Exception;
}