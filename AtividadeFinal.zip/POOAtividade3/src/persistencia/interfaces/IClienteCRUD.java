/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistencia.interfaces;

import negocio.modelo.Cliente;
import java.util.Iterator;

public interface IClienteCRUD {
    public void inserir(Cliente cliente) throws Exception;
    public void atualizar(Cliente cliente) throws Exception;
    public void excluir(int codCli) throws Exception;
    public Iterator<Cliente> listarTodos() throws Exception;
    public Cliente obterPorCodigo(int codCli) throws Exception;
    public Cliente obterPorCNPJ(String cnpj) throws Exception;
    public Cliente obterPorCPF(String cpf) throws Exception;
    public Cliente obterPorNome(String nome) throws Exception;
    public Iterator<Cliente> listarPorTipo(int tipo) throws Exception;
}