/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia.dao;

import negocio.modelo.Cidade;
import ferramentas.ConexaoBD;
import persistencia.interfaces.ICidadeCRUD;
import java.sql.*;
import java.util.Iterator;
import java.util.ArrayList;

public class CidadeDAO implements ICidadeCRUD {
    
    private Connection connection;

    public CidadeDAO() throws Exception {
        this.connection = ConexaoBD.getConexao();
    }

    @Override
    public void inserir(Cidade cidade) throws Exception {
        String sql = "INSERT INTO CIDADE (PRECO_UNIT_PESO, PRECO_UNIT_VALOR, NOME_CID, FK_ESTADO_UF) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDouble(1, cidade.getPrecoUnitPeso());
            stmt.setDouble(2, cidade.getPrecoUnitValor());
            stmt.setString(3, cidade.getNomeCid());
            stmt.setString(4, cidade.getFkEstadoUf());
            stmt.executeUpdate();
        }
    }

    @Override
    public void atualizar(Cidade cidade) throws Exception {
        String sql = "UPDATE CIDADE SET PRECO_UNIT_PESO = ?, PRECO_UNIT_VALOR = ?, NOME_CID = ?, FK_ESTADO_UF = ? WHERE CODIGO_CID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDouble(1, cidade.getPrecoUnitPeso());
            stmt.setDouble(2, cidade.getPrecoUnitValor());
            stmt.setString(3, cidade.getNomeCid());
            stmt.setString(4, cidade.getFkEstadoUf());
            stmt.setInt(5, cidade.getCodigoCid());
            stmt.executeUpdate();
        }
    }

    @Override
    public void excluir(int codigoCid) throws Exception {
        String sql = "DELETE FROM CIDADE WHERE CODIGO_CID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, codigoCid);
            stmt.executeUpdate();
        }
    }

    @Override
    public Iterator<Cidade> listarTodas() throws Exception {
        String sql = "SELECT * FROM CIDADE";
        ArrayList<Cidade> cidades = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Cidade cidade = new Cidade();
                cidade.setCodigoCid(rs.getInt("CODIGO_CID"));
                cidade.setPrecoUnitPeso(rs.getDouble("PRECO_UNIT_PESO"));
                cidade.setPrecoUnitValor(rs.getDouble("PRECO_UNIT_VALOR"));
                cidade.setNomeCid(rs.getString("NOME_CID"));
                cidade.setFkEstadoUf(rs.getString("FK_ESTADO_UF"));
                cidades.add(cidade);
            }
        }
        return cidades.iterator();
    }

    @Override
    public Cidade obterPorCodigo(int codigoCid) throws Exception {
        String sql = "SELECT * FROM CIDADE WHERE CODIGO_CID = ?";
        Cidade cidade = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, codigoCid);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cidade = new Cidade();
                    cidade.setCodigoCid(rs.getInt("CODIGO_CID"));
                    cidade.setPrecoUnitPeso(rs.getDouble("PRECO_UNIT_PESO"));
                    cidade.setPrecoUnitValor(rs.getDouble("PRECO_UNIT_VALOR"));
                    cidade.setNomeCid(rs.getString("NOME_CID"));
                    cidade.setFkEstadoUf(rs.getString("FK_ESTADO_UF"));
                }
            }
        }
        return cidade;
    }

    @Override
    public Cidade obterPorNome(String nome) throws Exception {
        String sql = "SELECT * FROM CIDADE WHERE NOME_CID = ?";
        Cidade cidade = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nome);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cidade = new Cidade();
                    cidade.setCodigoCid(rs.getInt("CODIGO_CID"));
                    cidade.setPrecoUnitPeso(rs.getDouble("PRECO_UNIT_PESO"));
                    cidade.setPrecoUnitValor(rs.getDouble("PRECO_UNIT_VALOR"));
                    cidade.setNomeCid(rs.getString("NOME_CID"));
                    cidade.setFkEstadoUf(rs.getString("FK_ESTADO_UF"));
                }
            }
        }
        return cidade;
    }

    @Override
    public Iterator<Cidade> listarPorEstado(String ufEstado) throws Exception {
        String sql = "SELECT * FROM CIDADE WHERE FK_ESTADO_UF = ?";
        ArrayList<Cidade> cidades = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, ufEstado);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Cidade cidade = new Cidade();
                    cidade.setCodigoCid(rs.getInt("CODIGO_CID"));
                    cidade.setPrecoUnitPeso(rs.getDouble("PRECO_UNIT_PESO"));
                    cidade.setPrecoUnitValor(rs.getDouble("PRECO_UNIT_VALOR"));
                    cidade.setNomeCid(rs.getString("NOME_CID"));
                    cidade.setFkEstadoUf(rs.getString("FK_ESTADO_UF"));
                    cidades.add(cidade);
                }
            }
        }
        return cidades.iterator();
    }
}