/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia.dao;

import negocio.modelo.Estado;
import ferramentas.ConexaoBD;
import persistencia.interfaces.IEstadoCRUD;
import java.sql.*;
import java.util.Iterator;
import java.util.ArrayList;

public class EstadoDAO implements IEstadoCRUD {
    
    private Connection connection;

    public EstadoDAO() throws Exception {
        this.connection = ConexaoBD.getConexao();
    }

    @Override
    public void inserir(Estado estado) throws Exception {
        String sql = "INSERT INTO ESTADO (UF, ICMS_LOCAL, ICMS_OUTRO_UF, NOME_EST) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, estado.getUf());
            stmt.setDouble(2, estado.getIcmsLocal());
            stmt.setDouble(3, estado.getIcmsOutroUf());
            stmt.setString(4, estado.getNomeEst());
            stmt.executeUpdate();
        }
    }

    @Override
    public void atualizar(Estado estado) throws Exception {
        String sql = "UPDATE ESTADO SET ICMS_LOCAL = ?, ICMS_OUTRO_UF = ?, NOME_EST = ? WHERE UF = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDouble(1, estado.getIcmsLocal());
            stmt.setDouble(2, estado.getIcmsOutroUf());
            stmt.setString(3, estado.getNomeEst());
            stmt.setString(4, estado.getUf());
            stmt.executeUpdate();
        }
    }

    @Override
    public void excluir(String uf) throws Exception {
        String sql = "DELETE FROM ESTADO WHERE UF = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, uf);
            stmt.executeUpdate();
        }
    }

    @Override
    public Iterator<Estado> listarTodos() throws Exception {
        String sql = "SELECT * FROM ESTADO";
        ArrayList<Estado> estados = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Estado estado = new Estado();
                estado.setUf(rs.getString("UF"));
                estado.setIcmsLocal(rs.getDouble("ICMS_LOCAL"));
                estado.setIcmsOutroUf(rs.getDouble("ICMS_OUTRO_UF"));
                estado.setNomeEst(rs.getString("NOME_EST"));
                estados.add(estado);
            }
        }
        return estados.iterator();
    }

    @Override
    public Estado obterPorUF(String uf) throws Exception {
        String sql = "SELECT * FROM ESTADO WHERE UF = ?";
        Estado estado = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, uf);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    estado = new Estado();
                    estado.setUf(rs.getString("UF"));
                    estado.setIcmsLocal(rs.getDouble("ICMS_LOCAL"));
                    estado.setIcmsOutroUf(rs.getDouble("ICMS_OUTRO_UF"));
                    estado.setNomeEst(rs.getString("NOME_EST"));
                }
            }
        }
        return estado;
    }

    @Override
    public Estado obterPorNome(String nome) throws Exception {
        String sql = "SELECT * FROM ESTADO WHERE NOME_EST = ?";
        Estado estado = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nome);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    estado = new Estado();
                    estado.setUf(rs.getString("UF"));
                    estado.setIcmsLocal(rs.getDouble("ICMS_LOCAL"));
                    estado.setIcmsOutroUf(rs.getDouble("ICMS_OUTRO_UF"));
                    estado.setNomeEst(rs.getString("NOME_EST"));
                }
            }
        }
        return estado;
    }

    @Override
    public String getNomeByUF(String uf) throws Exception {
        String sql = "SELECT NOME_EST FROM ESTADO WHERE UF = ?";
        String nomeEst = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, uf);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    nomeEst = rs.getString("NOME_EST");
                }
            }
        }
        return nomeEst;
    }
}