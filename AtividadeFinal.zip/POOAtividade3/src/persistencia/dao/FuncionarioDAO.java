/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia.dao;

import negocio.modelo.Funcionario;
import ferramentas.ConexaoBD;
import persistencia.interfaces.IFuncionarioCRUD;
import java.sql.*;
import java.util.Iterator;
import java.util.ArrayList;

public class FuncionarioDAO implements IFuncionarioCRUD {
    private Connection connection;

    public FuncionarioDAO() throws Exception {
        this.connection = ConexaoBD.getConexao();
    }

    @Override
    public void inserir(Funcionario funcionario) throws Exception {
        String sql = "INSERT INTO FUNCIONARIO (NOME_FUNC) VALUES (?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, funcionario.getNomeFunc());
            stmt.executeUpdate();
        }
    }

    @Override
    public void atualizar(Funcionario funcionario) throws Exception {
        String sql = "UPDATE FUNCIONARIO SET NOME_FUNC = ? WHERE NUM_REG = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, funcionario.getNomeFunc());
            stmt.setInt(2, funcionario.getNumReg());
            stmt.executeUpdate();
        }
    }

    @Override
    public void excluir(int numReg) throws Exception {
        String sql = "DELETE FROM FUNCIONARIO WHERE NUM_REG = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, numReg);
            stmt.executeUpdate();
        }
    }

    @Override
    public Iterator<Funcionario> listarTodos() throws Exception {
        String sql = "SELECT * FROM FUNCIONARIO";
        ArrayList<Funcionario> funcionarios = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Funcionario funcionario = new Funcionario();
                funcionario.setNumReg(rs.getInt("NUM_REG"));
                funcionario.setNomeFunc(rs.getString("NOME_FUNC"));
                funcionarios.add(funcionario);
            }
        }
        return funcionarios.iterator();
    }

    @Override
    public Funcionario obterPorNumReg(int numReg) throws Exception {
        String sql = "SELECT * FROM FUNCIONARIO WHERE NUM_REG = ?";
        Funcionario funcionario = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, numReg);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    funcionario = new Funcionario();
                    funcionario.setNumReg(rs.getInt("NUM_REG"));
                    funcionario.setNomeFunc(rs.getString("NOME_FUNC"));
                }
            }
        }
        return funcionario;
    }

    @Override
    public Funcionario obterPorNome(String nome) throws Exception {
        String sql = "SELECT * FROM FUNCIONARIO WHERE NOME_FUNC = ?";
        Funcionario funcionario = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nome);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    funcionario = new Funcionario();
                    funcionario.setNumReg(rs.getInt("NUM_REG"));
                    funcionario.setNomeFunc(rs.getString("NOME_FUNC"));
                }
            }
        }
        return funcionario;
    }
}