/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia.dao;

import negocio.modelo.Frete;
import ferramentas.ConexaoBD;
import persistencia.interfaces.IFreteCRUD;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FreteDAO implements IFreteCRUD {
    private Connection connection;

    public FreteDAO() throws Exception {
        this.connection = ConexaoBD.getConexao();
    }

    @Override
    public void inserir(Frete frete) throws Exception {
        String sql = "INSERT INTO FRETE (QUEM_PAGA, PESO_VALOR, PESO, VALOR, ICMS, DATA_FRETE, PEDAGIO, FK_CIDADE_ORIGEM, FK_CIDADE_DESTINO, FK_FUNCIONARIO_NUM_REG, FK_CLIENTE_REMETENTE, FK_CLIENTE_DESTINATARIO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, frete.getQuemPaga());
            stmt.setDouble(2, frete.getPesoValor());
            stmt.setDouble(3, frete.getPeso());
            stmt.setDouble(4, frete.getValor());
            stmt.setDouble(5, frete.getIcms());
            stmt.setDate(6, frete.getDataFrete());
            stmt.setDouble(7, frete.getPedagio());
            stmt.setInt(8, frete.getFkCidadeOrigem());
            stmt.setInt(9, frete.getFkCidadeDestino());
            stmt.setInt(10, frete.getFkFuncionarioNumReg());
            stmt.setInt(11, frete.getFkClienteRemetente());
            stmt.setInt(12, frete.getFkClienteDestinatario());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    frete.setNumConhec(generatedKeys.getInt(1));
                }
            }
        }
    }

    @Override
    public void atualizar(Frete frete) throws Exception {
        String sql = "UPDATE FRETE SET QUEM_PAGA = ?, PESO_VALOR = ?, PESO = ?, VALOR = ?, ICMS = ?, DATA_FRETE = ?, PEDAGIO = ?, FK_CIDADE_ORIGEM = ?, FK_CIDADE_DESTINO = ?, FK_FUNCIONARIO_NUM_REG = ?, FK_CLIENTE_REMETENTE = ?, FK_CLIENTE_DESTINATARIO = ? WHERE NUM_CONHEC = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, frete.getQuemPaga());
            stmt.setDouble(2, frete.getPesoValor());
            stmt.setDouble(3, frete.getPeso());
            stmt.setDouble(4, frete.getValor());
            stmt.setDouble(5, frete.getIcms());
            stmt.setDate(6, frete.getDataFrete());
            stmt.setDouble(7, frete.getPedagio());
            stmt.setInt(8, frete.getFkCidadeOrigem());
            stmt.setInt(9, frete.getFkCidadeDestino());
            stmt.setInt(10, frete.getFkFuncionarioNumReg());
            stmt.setInt(11, frete.getFkClienteRemetente());
            stmt.setInt(12, frete.getFkClienteDestinatario());
            stmt.setInt(13, frete.getNumConhec());
            stmt.executeUpdate();
        }
    }

    @Override
    public void excluir(int numConhecimento) throws Exception {
        String sql = "DELETE FROM FRETE WHERE NUM_CONHEC = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, numConhecimento);
            stmt.executeUpdate();
        }
    }

    @Override
    public Iterator<Frete> listarTodos() throws Exception {
        String sql = "SELECT * FROM FRETE";
        ArrayList<Frete> fretes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Frete frete = criarFrete(rs);
                fretes.add(frete);
            }
        }
        return fretes.iterator();
    }

    @Override
    public Frete obterPorNumeroConhecimento(int numConhecimento) throws Exception {
        String sql = "SELECT * FROM FRETE WHERE NUM_CONHEC = ?";
        Frete frete = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, numConhecimento);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    frete = criarFrete(rs);
                }
            }
        }
        return frete;
    }

    @Override
    public Iterator<Frete> listarPorCliente(int codCli) throws Exception {
        String sql = "SELECT * FROM FRETE WHERE FK_CLIENTE_REMETENTE = ? OR FK_CLIENTE_DESTINATARIO = ?";
        ArrayList<Frete> fretes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, codCli);
            stmt.setInt(2, codCli);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Frete frete = criarFrete(rs);
                    fretes.add(frete);
                }
            }
        }
        return fretes.iterator();
    }

    @Override
    public Iterator<Frete> listarPorFuncionario(int numReg) throws Exception {
        String sql = "SELECT * FROM FRETE WHERE FK_FUNCIONARIO_NUM_REG = ?";
        ArrayList<Frete> fretes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, numReg);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Frete frete = criarFrete(rs);
                    fretes.add(frete);
                }
            }
        }
        return fretes.iterator();
    }

    @Override
    public Iterator<Frete> listarPorData(Date dataInicio, Date dataFim) throws Exception {
        String sql = "SELECT * FROM FRETE WHERE DATA_FRETE BETWEEN ? AND ?";
        ArrayList<Frete> fretes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, new java.sql.Date(dataInicio.getTime()));
            stmt.setDate(2, new java.sql.Date(dataFim.getTime()));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Frete frete = criarFrete(rs);
                    fretes.add(frete);
                }
            }
        }
        return fretes.iterator();
    }

    private Frete criarFrete(ResultSet rs) throws SQLException {
        Frete frete = new Frete();
        frete.setNumConhec(rs.getInt("NUM_CONHEC"));
        frete.setQuemPaga(rs.getString("QUEM_PAGA"));
        frete.setPesoValor(rs.getDouble("PESO_VALOR"));
        frete.setPeso(rs.getDouble("PESO"));
        frete.setValor(rs.getDouble("VALOR"));
        frete.setIcms(rs.getDouble("ICMS"));
        frete.setDataFrete(rs.getDate("DATA_FRETE"));
        frete.setPedagio(rs.getDouble("PEDAGIO"));
        frete.setFkCidadeOrigem(rs.getInt("FK_CIDADE_ORIGEM"));
        frete.setFkCidadeDestino(rs.getInt("FK_CIDADE_DESTINO"));
        frete.setFkFuncionarioNumReg(rs.getInt("FK_FUNCIONARIO_NUM_REG"));
        frete.setFkClienteRemetente(rs.getInt("FK_CLIENTE_REMETENTE"));
        frete.setFkClienteDestinatario(rs.getInt("FK_CLIENTE_DESTINATARIO"));
        return frete;
    }

    @Override
    public List<Map<String, Object>> consultarArrecadacaoPorDestino(String uf, int ano) throws Exception {
       String sql = "SELECT c.NOME_CID AS cidade, e.UF AS estado, COUNT(f.NUM_CONHEC) AS quantidade_fretes, SUM(f.VALOR) AS valor_total "
                   + "FROM FRETE f "
                   + "JOIN CIDADE c ON f.FK_CIDADE_DESTINO = c.CODIGO_CID "
                   + "JOIN ESTADO e ON c.FK_ESTADO_UF = e.UF "
                   + "WHERE e.UF = ? AND EXTRACT(YEAR FROM f.DATA_FRETE) = ? "
                   + "GROUP BY c.NOME_CID, e.UF "
                   + "ORDER BY c.NOME_CID";

        List<Map<String, Object>> resultados = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, uf);
            stmt.setInt(2, ano);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> linha = new HashMap<>();
                    linha.put("cidade", rs.getString("cidade"));
                    linha.put("estado", rs.getString("estado"));
                    linha.put("quantidade_fretes", rs.getInt("quantidade_fretes"));
                    linha.put("valor_total", rs.getDouble("valor_total"));
                    resultados.add(linha);
                }
            }
        }

        return resultados;
    }

    @Override
    public List<Map<String, Object>> consultarMediaFretesPorCidade(String uf) throws Exception {
        String sql = "SELECT c.NOME_CID AS cidade, "
                   + "       e.UF AS estado, "
                   + "       AVG(origem.quantidade) AS media_fretes_origem, "
                   + "       AVG(destino.quantidade) AS media_fretes_destino "
                   + "FROM CIDADE c "
                   + "JOIN ESTADO e ON c.FK_ESTADO_UF = e.UF "
                   + "LEFT JOIN ( "
                   + "    SELECT FK_CIDADE_ORIGEM AS cidade_id, COUNT(NUM_CONHEC) AS quantidade "
                   + "    FROM FRETE "
                   + "    GROUP BY FK_CIDADE_ORIGEM "
                   + ") origem ON c.CODIGO_CID = origem.cidade_id "
                   + "LEFT JOIN ( "
                   + "    SELECT FK_CIDADE_DESTINO AS cidade_id, COUNT(NUM_CONHEC) AS quantidade "
                   + "    FROM FRETE "
                   + "    GROUP BY FK_CIDADE_DESTINO "
                   + ") destino ON c.CODIGO_CID = destino.cidade_id "
                   + "WHERE e.UF = ? "
                   + "GROUP BY c.NOME_CID, e.UF "
                   + "ORDER BY c.NOME_CID";

        List<Map<String, Object>> resultados = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, uf);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> linha = new HashMap<>();
                    linha.put("cidade", rs.getString("cidade"));
                    linha.put("estado", rs.getString("estado"));
                    linha.put("media_fretes_origem", rs.getDouble("media_fretes_origem"));
                    linha.put("media_fretes_destino", rs.getDouble("media_fretes_destino"));
                    resultados.add(linha);
                }
            }
        }

        return resultados;
    }  

    @Override
    public List<Map<String, Object>> consultarFretesPessoasJuridicas(int mes, int ano) throws Exception {
        String sql = "SELECT f.NUM_CONHEC AS numero_conhecimento, "
                   + "       func.NOME_FUNC AS nome_funcionario, "
                   + "       pj.RAZAO_SOCIAL AS pessoa_juridica, "
                   + "       rep.NOME_CLI AS representante "
                   + "FROM FRETE f "
                   + "JOIN FUNCIONARIO func ON f.FK_FUNCIONARIO_NUM_REG = func.NUM_REG "
                   + "JOIN CLIENTE pj ON f.FK_CLIENTE_REMETENTE = pj.COD_CLI OR f.FK_CLIENTE_DESTINATARIO = pj.COD_CLI "
                   + "LEFT JOIN REPRESENTANTE r ON pj.COD_CLI = r.FK_CLIENTE_REPRESENTADO "
                   + "LEFT JOIN CLIENTE rep ON r.FK_CLIENTE_REPRESENTANTE = rep.COD_CLI "
                   + "WHERE pj.CLIENTE_TIPO = 2 "
                   + "  AND EXTRACT(MONTH FROM f.DATA_FRETE) = ? "
                   + "  AND EXTRACT(YEAR FROM f.DATA_FRETE) = ? "
                   + "ORDER BY f.NUM_CONHEC";

        List<Map<String, Object>> resultados = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, mes);
            stmt.setInt(2, ano);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> linha = new HashMap<>();
                    linha.put("numero_conhecimento", rs.getInt("numero_conhecimento"));
                    linha.put("nome_funcionario", rs.getString("nome_funcionario"));
                    linha.put("pessoa_juridica", rs.getString("pessoa_juridica"));
                    linha.put("representante", rs.getString("representante"));
                    resultados.add(linha);
                }
            }
        }

        return resultados;
    }
}


