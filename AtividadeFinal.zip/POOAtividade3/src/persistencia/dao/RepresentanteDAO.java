/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia.dao;

import negocio.modelo.Representante;
import ferramentas.ConexaoBD;
import persistencia.interfaces.IRepresentanteCRUD;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;

public class RepresentanteDAO implements IRepresentanteCRUD {
    private Connection connection;

    public RepresentanteDAO() throws Exception {
        this.connection = ConexaoBD.getConexao();
    }

    @Override
    public void inserir(Representante representante) throws Exception {
        String sql = "INSERT INTO REPRESENTANTE (FK_CLIENTE_REPRESENTADO, FK_CLIENTE_REPRESENTANTE) VALUES (?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, representante.getFkClienteRepresentado());
            stmt.setInt(2, representante.getFkClienteRepresentante());
            stmt.executeUpdate();
        }
    }

    @Override
    public void atualizar(Representante representante) throws Exception {
        String sql = "UPDATE REPRESENTANTE SET FK_CLIENTE_REPRESENTANTE = ?, FK_CLIENTE_REPRESENTADO = ? WHERE ID_REPRESENTANTE = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, representante.getFkClienteRepresentante());
            stmt.setInt(2, representante.getFkClienteRepresentado());
            stmt.setInt(3, representante.getId());
            stmt.executeUpdate();
        }
    }


    @Override
    public void excluir(int idRepresentante) throws Exception {
        String sql = "DELETE FROM REPRESENTANTE WHERE ID_REPRESENTANTE = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idRepresentante);
            stmt.executeUpdate();
        }
    }

    @Override
    public Iterator<Representante> listarTodos() throws Exception {
        String sql = "SELECT * FROM REPRESENTANTE";
        ArrayList<Representante> representantes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Representante representante = criarRepresentante(rs);
                representantes.add(representante);
            }
        }
        return representantes.iterator();
    }

    @Override
    public Iterator<Representante> listarPorRepresentado(int idClienteRepresentado) throws Exception {
        String sql = "SELECT * FROM REPRESENTANTE WHERE FK_CLIENTE_REPRESENTADO = ?";
        ArrayList<Representante> representantes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idClienteRepresentado);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Representante representante = criarRepresentante(rs);
                    representantes.add(representante);
                }
            }
        }
        return representantes.iterator();
    }

    @Override
    public Iterator<Representante> listarPorRepresentante(int idClienteRepresentante) throws Exception {
        String sql = "SELECT * FROM REPRESENTANTE WHERE FK_CLIENTE_REPRESENTANTE = ?";
        ArrayList<Representante> representantes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idClienteRepresentante);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Representante representante = criarRepresentante(rs);
                    representantes.add(representante);
                }
            }
        }
        return representantes.iterator();
    }
    
    @Override
    public Representante obterRepresentante(int idRepresentante) throws Exception {
        String sql = "SELECT * FROM REPRESENTANTE WHERE ID_REPRESENTANTE = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, idRepresentante);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return criarRepresentante(rs); // Usa o método para criar o Representante
                } else {
                    throw new Exception("Representante não encontrado.");
                }
            }
        }
    }

    private Representante criarRepresentante(ResultSet rs) throws SQLException {
        Representante representante = new Representante();
        representante.setId(rs.getInt("ID_REPRESENTANTE"));
        representante.setFkClienteRepresentado(rs.getInt("FK_CLIENTE_REPRESENTADO"));
        representante.setFkClienteRepresentante(rs.getInt("FK_CLIENTE_REPRESENTANTE"));
        return representante;
    }
}

