/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia.dao;

import negocio.modelo.Cliente;
import ferramentas.ConexaoBD;
import persistencia.interfaces.IClienteCRUD;
import java.sql.*;
import java.util.Iterator;
import java.util.ArrayList;

public class ClienteDAO implements IClienteCRUD {

    private Connection connection;

    public ClienteDAO() throws Exception {
        this.connection = ConexaoBD.getConexao();
    }

    @Override
    public void inserir(Cliente cliente) throws Exception {
        String sql = "INSERT INTO CLIENTE (DATA_INSC, ENDERECO, TELEFONE, RAZAO_SOCIAL, INSC_ESTADUAL, CNPJ, NOME_CLI, CPF, CLIENTE_TIPO) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, new java.sql.Date(cliente.getDataInsc().getTime()));
            stmt.setString(2, cliente.getEndereco());
            stmt.setString(3, cliente.getTelefone());

            // Tratamento de valores opcionais:
            if (cliente.getRazaoSocial() != null) {
                stmt.setString(4, cliente.getRazaoSocial());
            } else {
                stmt.setNull(4, Types.VARCHAR);
            }

            if (cliente.getInscEstadual() != null) {
                stmt.setObject(5, cliente.getInscEstadual(), Types.INTEGER);
            } else {
                stmt.setNull(5, Types.INTEGER);
            }

            if (cliente.getCnpj() != null) {
                stmt.setString(6, cliente.getCnpj());
            } else {
                stmt.setNull(6, Types.VARCHAR);
            }

            stmt.setString(7, cliente.getNomeCli());

            if (cliente.getCpf() != null) {
                stmt.setString(8, cliente.getCpf());
            } else {
                stmt.setNull(8, Types.VARCHAR);
            }

            stmt.setInt(9, cliente.getClienteTipo());
            stmt.executeUpdate();
        }
    }

    @Override
    public void atualizar(Cliente cliente) throws Exception {
        String sql = "UPDATE CLIENTE SET DATA_INSC = ?, ENDERECO = ?, TELEFONE = ?, RAZAO_SOCIAL = ?, INSC_ESTADUAL = ?, CNPJ = ?, NOME_CLI = ?, CPF = ?, CLIENTE_TIPO = ? WHERE COD_CLI = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDate(1, new java.sql.Date(cliente.getDataInsc().getTime()));
            stmt.setString(2, cliente.getEndereco());
            stmt.setString(3, cliente.getTelefone());
            stmt.setString(4, cliente.getRazaoSocial());
            stmt.setInt(5, cliente.getInscEstadual());
            stmt.setString(6, cliente.getCnpj());
            stmt.setString(7, cliente.getNomeCli());
            stmt.setString(8, cliente.getCpf());
            stmt.setInt(9, cliente.getClienteTipo());
            stmt.setInt(10, cliente.getCodCli());
            stmt.executeUpdate();
        }
    }

    @Override
    public void excluir(int codCli) throws Exception {
        String sql = "DELETE FROM CLIENTE WHERE COD_CLI = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, codCli);
            stmt.executeUpdate();
        }
    }

    @Override
    public Iterator<Cliente> listarTodos() throws Exception {
        String sql = "SELECT * FROM CLIENTE";
        ArrayList<Cliente> clientes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setCodCli(rs.getInt("COD_CLI"));
                cliente.setDataInsc(rs.getDate("DATA_INSC"));
                cliente.setEndereco(rs.getString("ENDERECO"));
                cliente.setTelefone(rs.getString("TELEFONE"));
                cliente.setRazaoSocial(rs.getString("RAZAO_SOCIAL"));
                cliente.setInscEstadual(rs.getInt("INSC_ESTADUAL"));
                cliente.setCnpj(rs.getString("CNPJ"));
                cliente.setNomeCli(rs.getString("NOME_CLI"));
                cliente.setCpf(rs.getString("CPF"));
                cliente.setClienteTipo(rs.getInt("CLIENTE_TIPO"));
                clientes.add(cliente);
            }
        }
        return clientes.iterator();
    }

    @Override
    public Cliente obterPorCodigo(int codCli) throws Exception {
        String sql = "SELECT * FROM CLIENTE WHERE COD_CLI = ?";
        Cliente cliente = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, codCli);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente();
                    cliente.setCodCli(rs.getInt("COD_CLI"));
                    cliente.setDataInsc(rs.getDate("DATA_INSC"));
                    cliente.setEndereco(rs.getString("ENDERECO"));
                    cliente.setTelefone(rs.getString("TELEFONE"));
                    cliente.setRazaoSocial(rs.getString("RAZAO_SOCIAL"));
                    cliente.setInscEstadual(rs.getInt("INSC_ESTADUAL"));
                    cliente.setCnpj(rs.getString("CNPJ"));
                    cliente.setNomeCli(rs.getString("NOME_CLI"));
                    cliente.setCpf(rs.getString("CPF"));
                    cliente.setClienteTipo(rs.getInt("CLIENTE_TIPO"));
                }
            }
        }
        return cliente;
    }

    @Override
    public Cliente obterPorCNPJ(String cnpj) throws Exception {
        String sql = "SELECT * FROM CLIENTE WHERE CNPJ = ?";
        Cliente cliente = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, cnpj);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente();
                    cliente.setCodCli(rs.getInt("COD_CLI"));
                    cliente.setDataInsc(rs.getDate("DATA_INSC"));
                    cliente.setEndereco(rs.getString("ENDERECO"));
                    cliente.setTelefone(rs.getString("TELEFONE"));
                    cliente.setRazaoSocial(rs.getString("RAZAO_SOCIAL"));
                    cliente.setInscEstadual(rs.getInt("INSC_ESTADUAL"));
                    cliente.setCnpj(rs.getString("CNPJ"));
                    cliente.setNomeCli(rs.getString("NOME_CLI"));
                    cliente.setCpf(rs.getString("CPF"));
                    cliente.setClienteTipo(rs.getInt("CLIENTE_TIPO"));
                }
            }
        }
        return cliente;
    }

    @Override
    public Cliente obterPorCPF(String cpf) throws Exception {
        String sql = "SELECT * FROM CLIENTE WHERE CPF = ?";
        Cliente cliente = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, cpf);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente();
                    cliente.setCodCli(rs.getInt("COD_CLI"));
                    cliente.setDataInsc(rs.getDate("DATA_INSC"));
                    cliente.setEndereco(rs.getString("ENDERECO"));
                    cliente.setTelefone(rs.getString("TELEFONE"));
                    cliente.setRazaoSocial(rs.getString("RAZAO_SOCIAL"));
                    cliente.setInscEstadual(rs.getInt("INSC_ESTADUAL"));
                    cliente.setCnpj(rs.getString("CNPJ"));
                    cliente.setNomeCli(rs.getString("NOME_CLI"));
                    cliente.setCpf(rs.getString("CPF"));
                    cliente.setClienteTipo(rs.getInt("CLIENTE_TIPO"));
                }
            }
        }
        return cliente;
    }

    @Override
    public Cliente obterPorNome(String nome) throws Exception {
        String sql = "SELECT * FROM CLIENTE WHERE NOME_CLI = ?";
        Cliente cliente = null;
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, nome);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    cliente = new Cliente();
                    cliente.setCodCli(rs.getInt("COD_CLI"));
                    cliente.setDataInsc(rs.getDate("DATA_INSC"));
                    cliente.setEndereco(rs.getString("ENDERECO"));
                    cliente.setTelefone(rs.getString("TELEFONE"));
                    cliente.setRazaoSocial(rs.getString("RAZAO_SOCIAL"));
                    cliente.setInscEstadual(rs.getInt("INSC_ESTADUAL"));
                    cliente.setCnpj(rs.getString("CNPJ"));
                    cliente.setNomeCli(rs.getString("NOME_CLI"));
                    cliente.setCpf(rs.getString("CPF"));
                    cliente.setClienteTipo(rs.getInt("CLIENTE_TIPO"));
                }
            }
        }
        return cliente;
    }

    @Override
    public Iterator<Cliente> listarPorTipo(int tipo) throws Exception {
        String sql = "SELECT * FROM CLIENTE WHERE CLIENTE_TIPO = ?";
        ArrayList<Cliente> clientes = new ArrayList<>();
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, tipo);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Cliente cliente = new Cliente();
                    cliente.setCodCli(rs.getInt("COD_CLI"));
                    cliente.setDataInsc(rs.getDate("DATA_INSC"));
                    cliente.setEndereco(rs.getString("ENDERECO"));
                    cliente.setTelefone(rs.getString("TELEFONE"));
                    cliente.setRazaoSocial(rs.getString("RAZAO_SOCIAL"));
                    cliente.setInscEstadual(rs.getInt("INSC_ESTADUAL"));
                    cliente.setCnpj(rs.getString("CNPJ"));
                    cliente.setNomeCli(rs.getString("NOME_CLI"));
                    cliente.setCpf(rs.getString("CPF"));
                    cliente.setClienteTipo(rs.getInt("CLIENTE_TIPO"));
                    clientes.add(cliente);
                }
            }
        }
        return clientes.iterator();
    }
}
